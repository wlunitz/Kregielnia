import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-reservation-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reservation-form.html',
  styleUrls: ['./reservation-form.css']
})
export class ReservationForm {

  private http = inject(HttpClient);
    
  days: string[] = [];

  hours: string[] = [];

  requestedTracks = 1;
  totalTracks = 5;
  reservedSlots: string[] = [];
  reservations: any[] = [];
  tory: any[] = [];
  selectedDay: string | null = null;
  selectedHour: string | null = null;
  showModal = false;
  dayDates: Date[] = [];

  constructor() {
    this.generateDays();
    this.generateHours();
  }

  generateDays() {

    const today = new Date();

    for (let i = 0; i < 7; i++) {

      const date = new Date(today);
      date.setDate(today.getDate() + i);

      this.dayDates.push(new Date(date));

      const formatted = date.toLocaleDateString('pl-PL', {
        weekday: 'short',
        day: '2-digit',
        month: '2-digit'
      });

      this.days.push(formatted);
    }
  }

  generateHours() {

    for (let hour = 9; hour < 23; hour++) {

      const nextHour = hour + 1;

      this.hours.push(
        `${hour.toString().padStart(2, '0')}:00-${nextHour.toString().padStart(2, '0')}:00`
      );
    }
  }

  getDayDate(day: string): Date {

    const index = this.days.indexOf(day);

    return new Date(this.dayDates[index]);
  }

  openReservation(day: string, hour: string) {
    this.selectedDay = day;
    this.selectedHour = hour;
    this.showModal = true;
  }

  confirmReservation() {
    if (!this.selectedDay || !this.selectedHour) return;

    const match = this.selectedHour.match(/(\d+):00-(\d+):00/);
    const startHour = match ? Number(match[1]) : 0;

    const start = this.getDayDate(this.selectedDay);

    start.setHours(startHour, 0, 0, 0);

    const end = new Date(start);
    end.setHours(end.getHours() + 1);

    this.http.post('http://localhost:3000/api/rezerwacje', {
      data_poczatku: start.toISOString(),
      data_zakonczenia: end.toISOString(),
      iloscTorow: this.requestedTracks
    }).subscribe({
      next: () => {
        this.loadReservations();
        this.closeModal();
      },
      error: (err) => {
        alert(err.error?.error || 'Błąd rezerwacji');
      }
    });
  }

  closeModal() {
    this.showModal = false;
    this.selectedDay = null;
    this.selectedHour = null;
  }

  convertToDate(day: string, hour: string): Date {

    const date = this.getDayDate(day);

    const match = hour.match(/(\d+):00-(\d+):00/);

    const startHour = Number(match![1]);

    date.setHours(startHour, 0, 0, 0);

    return date;
  }

  isReserved(day: string, hour: string): boolean {

    const available = this.getAvailableTracks(day, hour);

    return available < this.requestedTracks;
  }

  loadTory() {
    this.http.get<any[]>('http://localhost:3000/api/tory')
      .subscribe(data => {
        this.tory = data;
        this.totalTracks = data.length;
      });
  }

  loadReservations() {
    this.http.get<any[]>('http://localhost:3000/api/rezerwacje')
      .subscribe(data => {
        this.reservations = data;
      });
  }

  ngOnInit() {
    this.loadTory();
    this.loadReservations();
  }

  getOccupiedTracks(day: string, hour: string): number {
    let occupied = 0;

    const slotDate = this.convertToDate(day, hour);

    for (const reservation of this.reservations) {

      const start = new Date(reservation.data_poczatku);
      const end = new Date(reservation.data_zakonczenia);

      if (slotDate >= start && slotDate < end) {
        occupied += reservation.tory
        ? reservation.tory.split(',').length
        : 0;
      }
    }

    return occupied;
  }

  getAvailableTracks(day: string, hour: string): number {
    return this.totalTracks - this.getOccupiedTracks(day, hour);
  }

}