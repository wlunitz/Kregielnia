import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-reservation-form',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reservation-form.html',
  styleUrls: ['./reservation-form.css']
})
export class ReservationForm {

  days: string[] = [];

  hours: string[] = [];

  reservedSlots: string[] = [];
  selectedDay: string | null = null;
  selectedHour: string | null = null;
  showModal = false;

  constructor() {
    this.generateDays();
    this.generateHours();
  }

  generateDays() {

    const today = new Date();

    for (let i = 0; i < 7; i++) {

      const date = new Date();

      date.setDate(today.getDate() + i);

      const formatted = date.toLocaleDateString('pl-PL', {
        weekday: 'short',
        day: '2-digit',
        month: '2-digit'
      });

      this.days.push(formatted);
    }
  }

  generateHours() {

    for (let hour = 9; hour < 23; hour++) {

      const nextHour = hour + 1;

      this.hours.push(
        `${hour.toString().padStart(2, '0')}:00-${nextHour.toString().padStart(2, '0')}:00`
      );
    }
  }

  openReservation(day: string, hour: string) {
    this.selectedDay = day;
    this.selectedHour = hour;
    this.showModal = true;
  }

  confirmReservation() {
    if (!this.selectedDay || !this.selectedHour) return;

    const slot = `${this.selectedDay}-${this.selectedHour}`;

    if (!this.reservedSlots.includes(slot)) {
      this.reservedSlots.push(slot);
    }

    this.closeModal();
  }

  closeModal() {
    this.showModal = false;
    this.selectedDay = null;
    this.selectedHour = null;
  }

  isReserved(day: string, hour: string): boolean {
    return this.reservedSlots.includes(`${day}-${hour}`);
  }
}