
// Mechanizm, który automatycznie "dokleja" token do każdego zapytania do API.

import { HttpInterceptorFn } from '@angular/common/http';

//Interceptor uwierzytelniający (Functional Interceptor).
//Przechwytuje wychodzące żądania HTTP i dołącza token JWT do nagłówków.
 
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  // Pobranie tokenu z magazynu lokalnego przeglądarki
  const token = localStorage.getItem('token');

  // Jeśli token istnieje, żądanie musi zostać zmodyfikowane
  if (token) {
    // Obiekty HttpRequest są niemutowalne (immutable). 
    // Aby zmienić nagłówki, należy sklonować żądanie.
    const cloned = req.clone({
      setHeaders: { 
        // Standardowo używa się formatu 'Bearer <token>', 
        // tutaj przesyłana jest surowa wartość tokenu.
        Authorization: token 
      }
    });

    // Przekazanie zmodyfikowanego żądania do kolejnego ogniwa w łańcuchu
    return next(cloned);
  }

  // Jeśli brak tokenu, żądanie przechodzi w niezmienionej formie
  return next(req);
};