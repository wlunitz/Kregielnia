import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user-profile.html'
})
export class UserProfile implements OnInit {
  // Wstrzykiwanie usługi HTTP za pomoca funkcji inject()
  private http = inject(HttpClient);


//Reaktywny stan profilu.
// Wykorzystanie obiektu wewnątrz sygnału pozwala na aktualizację całego zestawu danych.

  profile = signal({
    firstName: '',
    lastName: '',
    email: '',
    phone: ''
  });

  statusMessage = '';

  ngOnInit() {
    this.loadMyData();
  }

  
  //Pobiera dane profilowe aktualnie zalogowanego użytkownika.
  //Zakłada istnienie mechanizmu uwierzytelniania (np. HttpInterceptor dodający token JWT).
   
  loadMyData() {
  this.http.get<any>('http://localhost:3000/api/user/profile').subscribe({
    next: (data) => this.profile.set({
      firstName: data.firstName || '',
      lastName: data.lastName || '',
      email: data.email || '',
      phone: data.phone || ''
    }),
    error: (err) => console.error('Nie udało się załadować danych', err)
  });
}

  
// Wysyła zaktualizowane dane profilu na serwer metodą PUT.
  saveProfile() {
    // Pobranie aktualnej wartośći sygnału (getter)
    const data = this.profile();
    
    // Walidacja logiki biznesowej przed wysyłką żądania
    if (!data.firstName || !data.lastName) {
      this.statusMessage = 'Imię i nazwisko są wymagane.';
      return;
    }

    this.http.put('http://localhost:3000/api/user/profile', data)
      .subscribe({
        next: () => {
          this.statusMessage = 'Dane zostały pomyślnie zaktualizowane!';
          // Zarządzanie UI: automatyczne czyszczenie komunikatu sukcesu po 3 sekundach
          setTimeout(() => this.statusMessage = '', 3000);
        },
        error: (err) => {
          this.statusMessage = 'Wystąpił błąd podczas zapisu.';
          console.error(err);
        }
      });
  }
}