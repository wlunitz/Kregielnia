// src/app/components/login/login.component.ts
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {
  // Wstrzykiwanie AuthService do obsługi logiki biznesowej oraz Routera do nawigacji
  private authService = inject(AuthService);
  private router = inject(Router);

  // Właściwości powiązane z szablonem za pomocą [(ngModel)]
  email = '';
  password = '';
  errorMessage = '';

  
  //Główna metoda logowania wywoływana z formularza.
  
  onLogin() {
    // Resetowanie błędu przed kolejną próbą
    this.errorMessage = '';

    const credentials = {
      email: this.email,
      password: this.password
    };

    // Wywołanie usługi AuthService, która zwraca Observable (np. z HttpClient.post)
    this.authService.login(credentials).subscribe({
      next: (res) => {
        
        // Kontrola przepływu (Routing) na podstawie roli zwróconej z API.
        //To podejście zakłada, że serwer zwraca obiekt z polem 'role'.
         
        if (res.role === 'admin') {
          this.router.navigate(['/admin']);
        } else {
          this.router.navigate(['/user']);
        }
      },
      error: (err) => {
        // Mapowanie błędów HTTP na komunikat przyjazny dla użytkownika
        this.errorMessage = 'Nieprawidłowy email lub hasło.';
        console.error('Login error:', err);
      }
    });
  }
}