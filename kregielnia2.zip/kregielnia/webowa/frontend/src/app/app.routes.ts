// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { Login } from './login/login';
import { Admin } from './admin/admin';
import { UserProfile } from './user-profile/user-profile';
import { ReservationForm } from './reservation-form/reservation-form';
import { Home } from './home/home';
import { Register } from './register/register';

export const routes: Routes = [
  // Stan 1: Jawne punkty wejścia
  { path: 'login', component: Login },
  { path: 'admin', component: Admin },
  { path: 'register', component: Register },
  { path: '', component: Home},
  
  // Stan 2: Aliasy (Dwa adresy wskazują na ten sam komponent profilu)
  // Dobra praktyka: 'user' dla logiki biznesowej, 'profile' dla czytelności menu
  { path: 'user', component: UserProfile},
  { path: 'profile', component: UserProfile},
  { path: 'reservation', component: ReservationForm },

  // Stan 4: "Failsafe" (Obsługa błędnego adresu)
  // Gwiazdki '**' to tzw. Wildcard. Każdy adres niepasujący do powyższych
  // (np. localhost:4200/nieistnieje) zostanie przekierowany do logowania.
  { path: '**', redirectTo: 'login' }
];