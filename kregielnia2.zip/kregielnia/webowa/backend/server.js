// server.js
const express = require('express');
const Database = require('better-sqlite3');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
const db = new Database('database.db');
db.pragma('foreign_keys = ON');
const SECRET = 'sekretne_haslo_jwt';

app.use(express.json());
app.use(cors());

// Inicjalizacja bazy
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user',
    active INTEGER DEFAULT 1,
    firstName TEXT,
    lastName TEXT,
    phone TEXT
  );

  CREATE TABLE IF NOT EXISTS tory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numer INTEGER UNIQUE
  );

  CREATE TABLE IF NOT EXISTS rezerwacje (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_klienta INTEGER,
    data_poczatku TEXT,
    data_zakonczenia TEXT,
    FOREIGN KEY(id_klienta) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS rezerwacje_tory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_toru INTEGER,
    id_rezerwacji INTEGER,
    FOREIGN KEY(id_toru) REFERENCES tory(id) ON DELETE CASCADE,
    FOREIGN KEY(id_rezerwacji) REFERENCES rezerwacje(id) ON DELETE CASCADE
  );`);


const seedAdmin = () => {
    const adminEmail = 'admin@test.pl';
    // Sprawdzamy czy admin już istnieje
    const admin = db.prepare('SELECT id FROM users WHERE role = ?').get('admin');

    if (!admin) {
    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync('admin123', salt);
    
    db.prepare('INSERT INTO users (email, password, role, active) VALUES (?, ?, ?, ?)')
      .run(adminEmail, hashedPassword, 'admin', 1); 
    
    console.log(`[Database] Utworzono domyślnego admina: ${adminEmail}`);
}
};

seedAdmin();

const seedTory = () => {
  const count = db.prepare('SELECT COUNT(*) as c FROM tory').get();

  if (count.c === 0) {
    const stmt = db.prepare('INSERT INTO tory (numer) VALUES (?)');

    for (let i = 1; i <= 5; i++) {
      stmt.run(i);
    }

    console.log('[Database] Dodano 5 torów');
  }
};

seedTory();


// Middleware do weryfikacji JWT
const auth = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1]; // Pobranie tokena z nagłówka
    if (!token) return res.status(403).send('Brak tokenu');

    jwt.verify(token, SECRET, (err, decoded) => {
        if (err) return res.status(401).send('Brak autoryzacji');
        req.user = decoded; // Wypakowanie danych (id, role) do obiektu żądania
        next(); // Przejście do właściwej funkcji endpointu
    });
};



// Definicja endpointu logowania metodą POST
app.post('/api/login', (req, res) => {
    // Ekstrakcja danych z ciała żądania (destrukturyzacja obiektu)
    const { email, password } = req.body;

    // Przygotowanie i wykonanie zapytania do SQLite (better-sqlite3)
    // Używamy bindowania parametru (?) aby zapobiec atakom SQL Injection
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    
    // Logika weryfikacji (Bramka logiczna AND):
    // 1. Sprawdzenie czy użytkownik w ogóle istnieje w bazie
    // 2. Porównanie hasła z hashem przy użyciu bcrypt (bezpieczne porównanie odporne na timing attacks)
    // 3. Weryfikacja flagi 'active' - blokada dostępu dla zdezaktywowanych kont
    if (user && bcrypt.compareSync(password, user.password) && user.active) {
        
        // Generowanie tokena JWT (JSON Web Token):
        // Payload zawiera ID i rolę (do autoryzacji w kolejnych żądaniach)
        // Całość podpisana kluczem SECRET, co gwarantuje niezmienność danych (integralność)
        const token = jwt.sign({ id: user.id, role: user.role }, SECRET);
        
        // Wysłanie odpowiedzi sukcesu z tokenem i rolą (do logiki routingu na froncie)
        res.json({ token, role: user.role });
    } else {
        // W przypadku błędu wysyłamy status 401 (Unauthorized)
        // Ważne: Komunikat jest ogólny, aby nie zdradzać czy błędny jest email czy hasło (bezpieczeństwo)
        res.status(401).send('Nieprawidłowe dane logowania lub nieaktywne konto');
    }
});



// Admin: Dodawanie nowego klienta
app.post('/api/admin/clients', auth, (req, res) => {
    // 1. Autoryzacja - tylko admin może dodawać
    if (req.user.role !== 'admin') {
        return res.status(403).send('Zakaz: Wymagany dostęp administratora');
    }

    const { email, password } = req.body;

    // 2. Walidacja wejścia
    if (!email || !password) {
        return res.status(400).send('Email i hasło są wymagane');
    }

    try {
        // 3. Hashowanie hasła przed zapisem 
        const hashedPassword = bcrypt.hashSync(password, 10);

        // 4. Próba zapisu do bazy
        const stmt = db.prepare('INSERT INTO users (email, password, role, active) VALUES (?, ?, ?, ?)');
        const info = stmt.run(email, hashedPassword, 'user', 1);

        res.status(201).json({ id: info.lastInsertRowid, message: 'Klient dodany pomyślnie' });
    } catch (err) {
        // Obsługa błędu unikalności emaila (UNIQUE constraint w SQLite)
        if (err.message.includes('UNIQUE constraint failed')) {
            return res.status(409).send('Taki użytkownik już istnieje');
        }
        res.status(500).send('Błąd serwera');
    }
});

// Admin: Pobranie wszystkich klientów
app.get('/api/admin/clients', auth, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).send('Zakaz: Wymagany dostęp administratora');
    const clients = db.prepare("SELECT * FROM users WHERE role = 'user'").all();
    res.json(clients);
});

// Admin: Zmiana statusu aktywności
app.patch('/api/admin/clients/:id', auth, (req, res) => {
    // 1. Sprawdzamy co przyszło (diagnostyka)
    const { active } = req.body;
    const clientId = req.params.id;
    
    console.log(`Próba zmiany statusu klienta ${clientId} na: ${active}`);

    try {
        // 2. Przygotowanie zapytania
        const stmt = db.prepare('UPDATE users SET active = ? WHERE id = ?');
        
        // 3. Wykonanie i przechwycenie wyniku
        // Używamy Number(active), aby upewnić się, że wysyłamy 0 lub 1
        const info = stmt.run(active ? 1 : 0, clientId);

        if (info.changes > 0) {
            // Zmieniamy sendStatus na .json, aby Angular poprawnie odebrał odpowiedź
            res.json({ success: true, message: 'Status zaktualizowany' });
        } else {
            res.status(404).json({ error: 'Nie znaleziono użytkownika o takim ID' });
        }
    } catch (err) {
        console.error('Błąd bazy danych:', err);
        res.status(500).json({ error: 'Błąd serwera' });
    }
});

// Klient: Aktualizacja własnych danych
app.put('/api/user/profile', auth, (req, res) => {
    const { firstName, lastName, email, phone } = req.body;
    const userId = req.user.id; 

    try {
        const stmt = db.prepare(`
            UPDATE users
            SET firstName = ?, lastName = ?, email = ?, phone = ?
            WHERE id = ?
        `);
        stmt.run(firstName, lastName, email, phone, userId);
        
        // Zwracamy JSON, żeby Angular nie miał problemów z "Unexpected token O"
        res.status(200).json({ message: 'Profil zaktualizowany' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Błąd bazy danych' });
    }
});

// server.js - dodaj ten endpoint
app.get('/api/user/profile', auth, (req, res) => {
    const user = db.prepare('SELECT email, firstName, lastName, phone FROM users WHERE id = ?')
                  .get(req.user.id);
    if (user) {
        res.json(user);
    } else {
        res.status(404).json({ error: 'Użytkownik nie istnieje' });
    }
});

// Admin: Usuwanie klienta
app.delete('/api/admin/clients/:id', auth, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Brak uprawnień' });
    }

    const userId = req.params.id;

    try {
        const stmt = db.prepare('DELETE FROM users WHERE id = ? AND role = ?');
        const result = stmt.run(userId, 'user');

        if (result.changes > 0) {
            res.json({ message: 'Użytkownik został usunięty' });
        } else {
            res.status(404).json({ error: 'Nie znaleziono klienta' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Błąd bazy danych' });
    }
});


// Nowe enpointy --------------------------------------------------------------------------
app.post('/api/admin/tory', auth, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Brak uprawnień' });
    }

    const { numer } = req.body;
    if (!numer) return res.status(400).json({ error: 'Numer toru jest wymagany' });

    try {
        const stmt = db.prepare('INSERT INTO tory (numer) VALUES (?)');
        const info = stmt.run(numer);
        res.status(201).json({ id: info.lastInsertRowid, message: 'Tor dodany' });
    } catch (err) {
        if (err.message.includes('UNIQUE constraint failed')) {
            return res.status(409).json({ error: 'Taki tor już istnieje' });
        }
        res.status(500).json({ error: 'Błąd serwera' });
    }
});

app.get('/api/tory', (req, res) => {
    const rows = db.prepare('SELECT * FROM tory').all();
    res.json(rows);
});

app.delete('/api/admin/tory/:id', auth, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Brak uprawnień' });
    }

    const id = req.params.id;
    const stmt = db.prepare('DELETE FROM tory WHERE id = ?');
    const result = stmt.run(id);

    if (result.changes > 0) {
        res.json({ message: 'Tor usunięty' });
    } else {
        res.status(404).json({ error: 'Nie znaleziono toru' });
    }
});

const createReservation = db.transaction((userId, data_poczatku, data_zakonczenia, tory) => {
    const reservationId = db.prepare(`
        INSERT INTO rezerwacje (id_klienta, data_poczatku, data_zakonczenia)
        VALUES (?, ?, ?)
    `).run(userId, data_poczatku, data_zakonczenia).lastInsertRowid;

    const stmt = db.prepare(`
        INSERT INTO rezerwacje_tory (id_toru, id_rezerwacji)
        VALUES (?, ?)
    `);

    for (const torId of tory) {
        stmt.run(torId, reservationId);
    }

    return reservationId;
});


// ENDPOINT
app.post('/api/rezerwacje', auth, (req, res) => {
    const { data_poczatku, data_zakonczenia, iloscTorow } = req.body;
    const userId = req.user.id;

    if (!data_poczatku || !data_zakonczenia || !iloscTorow) {
        return res.status(400).json({ error: 'Brak wymaganych danych' });
    }

    try {

        const freeTracks = db.prepare(`
            SELECT t.id
            FROM tory t
            WHERE t.id NOT IN (
                SELECT rt.id_toru
                FROM rezerwacje r
                JOIN rezerwacje_tory rt
                    ON r.id = rt.id_rezerwacji
                WHERE r.data_poczatku < ?
                AND r.data_zakonczenia > ?
            )
            LIMIT ?
        `).all(data_zakonczenia, data_poczatku, iloscTorow);

        if (freeTracks.length < iloscTorow) {
            return res.status(409).json({
                error: 'Brak wystarczającej liczby wolnych torów'
            });
        }

        const selectedTracks = freeTracks.map(t => t.id);

        const reservationId = createReservation(
            userId,
            data_poczatku,
            data_zakonczenia,
            selectedTracks
        );

        res.status(201).json({
            message: 'Rezerwacja utworzona',
            id: reservationId
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Błąd serwera' });
    }
});

app.get('/api/rezerwacje', (req, res) => {
    try {
        const rows = db.prepare(`
            SELECT
                r.*,
                GROUP_CONCAT(rt.id_toru) AS tory
            FROM rezerwacje r
            LEFT JOIN rezerwacje_tory rt
                ON r.id = rt.id_rezerwacji
            GROUP BY r.id
        `).all();

        res.json(rows);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Błąd serwera' });
    }
});

app.get('/api/rezerwacje/moje', auth, (req, res) => {
    const userId = req.user.id;

    try {
        const rows = db.prepare(`
            SELECT 
                r.*,
                GROUP_CONCAT(rt.id_toru) AS tory
            FROM rezerwacje r
            LEFT JOIN rezerwacje_tory rt ON r.id = rt.id_rezerwacji
            WHERE r.id_klienta = ?
            GROUP BY r.id
        `).all(userId);

        res.json(rows);

    } catch (err) {
        console.error('Błąd /api/rezerwacje/moje:', err);
        res.status(500).json({ error: 'Błąd serwera' });
    }
});

app.get('/api/admin/rezerwacje', auth, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Brak uprawnień' });
    }

    const rows = db.prepare(`
        SELECT 
            r.*,
            u.email,
            GROUP_CONCAT(rt.id_toru) AS tory
        FROM rezerwacje r
        JOIN users u ON r.id_klienta = u.id
        LEFT JOIN rezerwacje_tory rt ON r.id = rt.id_rezerwacji
        GROUP BY r.id
    `).all();

    res.json(rows);
});

app.delete('/api/rezerwacje/:id', auth, (req, res) => {
    const id = req.params.id;
    const userId = req.user.id;

    const reservation = db.prepare('SELECT * FROM rezerwacje WHERE id = ?').get(id);

    if (!reservation) {
        return res.status(404).json({ error: 'Rezerwacja nie istnieje' });
    }

    if (reservation.id_klienta !== userId && req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Brak uprawnień' });
    }

    db.prepare('DELETE FROM rezerwacje WHERE id = ?').run(id);

    res.json({ message: 'Rezerwacja usunięta' });
});

app.post('/api/register', (req, res) => {
    const { firstName, lastName, email, phone, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Brak danych' });
    }

    try {
        const hashed = bcrypt.hashSync(password, 10);

        db.prepare(`
            INSERT INTO users (firstName, lastName, email, phone, password, role, active)
            VALUES (?, ?, ?, ?, ?, 'user', 1)
        `).run(firstName, lastName, email, phone, hashed);

        res.status(201).json({ message: 'Użytkownik utworzony' });

    } catch (err) {
        res.status(500).json({ error: 'Błąd rejestracji' });
    }
});



// -------------------------------------------------------------------
app.listen(3000, () => console.log('Serwer backend działa na porcie 3000'));