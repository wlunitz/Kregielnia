
// Mechanizm, który automatycznie "dokleja" token do każdego zapytania do API.

import { HttpInterceptorFn } from '@angular/common/http';

//Interceptor uwierzytelniający (Functional Interceptor).
//Przechwytuje wychodzące żądania HTTP i dołącza token JWT do nagłówków.
 
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('token');

  if (token) {
    const cloned = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });

    return next(cloned);
  }

  return next(req);
};