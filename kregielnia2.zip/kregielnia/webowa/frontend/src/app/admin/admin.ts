import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin.html'
})
export class Admin implements OnInit {
 // Wstrzykiwanie zależności za pomocą inject() - preferowane w nowym Angularze zamiast konstruktora
  private http = inject(HttpClient);
  
  // Reaktywne zarządzanie stanem listy klientów za pomocą sygnału (Signals)
  clients = signal<any[]>([]);
  
  // Pola powiązane z formularzem (Two-way binding w template)
  newEmail = '';
  newPass = '';

  ngOnInit() {
    this.fetchClients();
  }

  // Pobieranie listy wszystkich użytkowników z rolą 'user'
  // Wykorzystuje metodę .set() na sygnale, co powiadamia widok o zmianie.
  
  fetchClients() {
    console.log('FETCH CLIENTS START');
    this.http.get<any[]>('http://localhost:3000/api/admin/clients')
      .subscribe({
        next: (data) => this.clients.set(data),
        error: (err) => console.error('Błąd pobierania danych:', err)
      });
  }

  // Dodawanie nowego klienta
  // Wysyła żądanie POST w celu utworzenia nowego klienta.
  // Po sukcesie wykonuje ponowne pobranie danych (Side effect).
  addClient() {
    if (!this.newEmail || !this.newPass) {
      alert('Wypełnij email i hasło');
      return;
    }

    const payload = { email: this.newEmail, password: this.newPass };

    this.http.post('http://localhost:3000/api/admin/clients', payload)
      .subscribe({
        next: () => {
          this.fetchClients(); // Odświeżamy listę po sukcesie
          this.newEmail = '';  // Czyścimy formularz
          this.newPass = '';
        },
        error: (err) => alert(err.error || 'Błąd podczas dodawania klienta')
      });
  }

  //usuwanie klienta
  // Usuwa klienta na podstawie ID.
   // Zastosowano update() na sygnale - niemutowalne filtrowanie tablicy w pamięci.
  deleteClient(id: number) {
  if (confirm('Czy na pewno chcesz trwale usunąć tego użytkownika?')) {
    this.http.delete(`http://localhost:3000/api/admin/clients/${id}`)
      .subscribe({
        next: () => {
          // Reaktywna aktualizacja listy (usuwamy element z sygnału)
          this.clients.update(list => list.filter(c => c.id !== id));
        },
        error: (err) => alert('Błąd podczas usuwania: ' + err.error)
      });
  }
}

  // Zmiana statusu aktywności (checkbox/switch)
  //Przełącza status aktywności (0/1).
  
  toggleActive(client: any) {
    // Inwersja stanu: jeśli 1 to 0, jeśli 0 to 1
    const nextStatus = client.active === 1 ? 0 : 1;

    this.http.patch(`http://localhost:3000/api/admin/clients/${client.id}`, { 
      active: nextStatus 
    }).subscribe({
      next: () => {
        // Optymistyczna aktualizacja lokalnego stanu sygnału (bez ponownego GET)
        this.clients.update(currentList => 
          currentList.map(c => 
            c.id === client.id ? { ...c, active: nextStatus } : c
          )
        );
      },
      error: (err) => {
        alert('Nie udało się zmienić statusu');
        console.error(err);
      }
    });
  }
}