USE kregielnia;

CREATE TABLE Klienci (
    id INT AUTO_INCREMENT PRIMARY KEY,
    imie VARCHAR(100) NOT NULL,
    nazwisko VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    nr_tel VARCHAR(20) NOT NULL
);

CREATE TABLE Tory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numer INT NOT NULL
);

CREATE TABLE Rezerwacje (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_klient INT NOT NULL,
    data_zalozenia DATE NOT NULL,
    data_poczatkowa DATE NOT NULL,

    CONSTRAINT fk_rezerwacje_klienci
        FOREIGN KEY (id_klient)
        REFERENCES Klienci(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE Rezerwacje_Tory (
    id_rezerwacji INT NOT NULL,
    id_toru INT NOT NULL,

    PRIMARY KEY (id_rezerwacji, id_toru),

    CONSTRAINT fk_rt_rezerwacje
        FOREIGN KEY (id_rezerwacji)
        REFERENCES Rezerwacje(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT fk_rt_tory
        FOREIGN KEY (id_toru)
        REFERENCES Tory(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);