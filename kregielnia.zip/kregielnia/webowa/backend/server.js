// server.js
const express = require('express');
const Database = require('better-sqlite3');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
const db = new Database('database.db');
const SECRET = 'sekretne_haslo_jwt';

app.use(express.json());
app.use(cors());

// Inicjalizacja bazy
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user',
    active INTEGER DEFAULT 1,
    firstName TEXT,
    lastName TEXT,
    phone TEXT
  )
`);

const seedAdmin = () => {
    const adminEmail = 'admin@test.pl';
    // Sprawdzamy czy admin już istnieje
    const admin = db.prepare('SELECT id FROM users WHERE role = ?').get('admin');

    if (!admin) {
    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync('admin123', salt);
    
    db.prepare('INSERT INTO users (email, password, role, active) VALUES (?, ?, ?, ?)')
      .run(adminEmail, hashedPassword, 'admin', 1); 
    
    console.log(`[Database] Utworzono domyślnego admina: ${adminEmail}`);
}
};

seedAdmin();



// Middleware do weryfikacji JWT
const auth = (req, res, next) => {
    const token = req.headers['authorization']; // Pobranie tokena z nagłówka
    if (!token) return res.status(403).send('Brak tokenu');

    jwt.verify(token, SECRET, (err, decoded) => {
        if (err) return res.status(401).send('Brak autoryzacji');
        req.user = decoded; // Wypakowanie danych (id, role) do obiektu żądania
        next(); // Przejście do właściwej funkcji endpointu
    });
};



// Definicja endpointu logowania metodą POST
app.post('/api/login', (req, res) => {
    // Ekstrakcja danych z ciała żądania (destrukturyzacja obiektu)
    const { email, password } = req.body;

    // Przygotowanie i wykonanie zapytania do SQLite (better-sqlite3)
    // Używamy bindowania parametru (?) aby zapobiec atakom SQL Injection
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    
    // Logika weryfikacji (Bramka logiczna AND):
    // 1. Sprawdzenie czy użytkownik w ogóle istnieje w bazie
    // 2. Porównanie hasła z hashem przy użyciu bcrypt (bezpieczne porównanie odporne na timing attacks)
    // 3. Weryfikacja flagi 'active' - blokada dostępu dla zdezaktywowanych kont
    if (user && bcrypt.compareSync(password, user.password) && user.active) {
        
        // Generowanie tokena JWT (JSON Web Token):
        // Payload zawiera ID i rolę (do autoryzacji w kolejnych żądaniach)
        // Całość podpisana kluczem SECRET, co gwarantuje niezmienność danych (integralność)
        const token = jwt.sign({ id: user.id, role: user.role }, SECRET);
        
        // Wysłanie odpowiedzi sukcesu z tokenem i rolą (do logiki routingu na froncie)
        res.json({ token, role: user.role });
    } else {
        // W przypadku błędu wysyłamy status 401 (Unauthorized)
        // Ważne: Komunikat jest ogólny, aby nie zdradzać czy błędny jest email czy hasło (bezpieczeństwo)
        res.status(401).send('Nieprawidłowe dane logowania lub nieaktywne konto');
    }
});



// Admin: Dodawanie nowego klienta
app.post('/api/admin/clients', auth, (req, res) => {
    // 1. Autoryzacja - tylko admin może dodawać
    if (req.user.role !== 'admin') {
        return res.status(403).send('Zakaz: Wymagany dostęp administratora');
    }

    const { email, password } = req.body;

    // 2. Walidacja wejścia
    if (!email || !password) {
        return res.status(400).send('Email i hasło są wymagane');
    }

    try {
        // 3. Hashowanie hasła przed zapisem 
        const hashedPassword = bcrypt.hashSync(password, 10);

        // 4. Próba zapisu do bazy
        const stmt = db.prepare('INSERT INTO users (email, password, role, active) VALUES (?, ?, ?, ?)');
        const info = stmt.run(email, hashedPassword, 'user', 1);

        res.status(201).json({ id: info.lastInsertRowid, message: 'Klient dodany pomyślnie' });
    } catch (err) {
        // Obsługa błędu unikalności emaila (UNIQUE constraint w SQLite)
        if (err.message.includes('UNIQUE ...')) {
            return res.status(409).send('Taki użytkownik już istnieje');
        }
        res.status(500).send('Błąd serwera');
    }
});

// Admin: Pobranie wszystkich klientów
app.get('/api/admin/clients', auth, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).send('Zakaz: Wymagany dostęp administratora');
    const clients = db.prepare("SELECT * FROM users WHERE role = 'user'").all();
    res.json(clients);
});

// Admin: Zmiana statusu aktywności
app.patch('/api/admin/clients/:id', auth, (req, res) => {
    // 1. Sprawdzamy co przyszło (diagnostyka)
    const { active } = req.body;
    const clientId = req.params.id;
    
    console.log(`Próba zmiany statusu klienta ${clientId} na: ${active}`);

    try {
        // 2. Przygotowanie zapytania
        const stmt = db.prepare('UPDATE users SET active = ? WHERE id = ?');
        
        // 3. Wykonanie i przechwycenie wyniku
        // Używamy Number(active), aby upewnić się, że wysyłamy 0 lub 1
        const info = stmt.run(active ? 1 : 0, clientId);

        if (info.changes > 0) {
            // Zmieniamy sendStatus na .json, aby Angular poprawnie odebrał odpowiedź
            res.json({ success: true, message: 'Status zaktualizowany' });
        } else {
            res.status(404).json({ error: 'Nie znaleziono użytkownika o takim ID' });
        }
    } catch (err) {
        console.error('Błąd bazy danych:', err);
        res.status(500).json({ error: 'Błąd serwera' });
    }
});

// Klient: Aktualizacja własnych danych
app.put('/api/user/profile', auth, (req, res) => {
    const { firstName, lastName, email, phone } = req.body;
    const userId = req.user.id; 

    try {
        const stmt = db.prepare(`
            UPDATE users
            SET firstName = ?, lastName = ?, email = ?, phone = ?
            WHERE id = ?
        `);
        stmt.run(firstName, lastName, email, phone, userId);
        
        // Zwracamy JSON, żeby Angular nie miał problemów z "Unexpected token O"
        res.status(200).json({ message: 'Profil zaktualizowany' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Błąd bazy danych' });
    }
});

// server.js - dodaj ten endpoint
app.get('/api/user/profile', auth, (req, res) => {
    const user = db.prepare('SELECT email, firstName, lastName, phone FROM users WHERE id = ?')
                  .get(req.user.id);
    if (user) {
        res.json(user);
    } else {
        res.status(404).json({ error: 'Użytkownik nie istnieje' });
    }
});

// Admin: Usuwanie klienta
app.delete('/api/admin/clients/:id', auth, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Brak uprawnień' });
    }

    const userId = req.params.id;

    try {
        const stmt = db.prepare('DELETE FROM users WHERE id = ? AND role = ?');
        const result = stmt.run(userId, 'user');

        if (result.changes > 0) {
            res.json({ message: 'Użytkownik został usunięty' });
        } else {
            res.status(404).json({ error: 'Nie znaleziono klienta' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Błąd bazy danych' });
    }
});

// -------------------------------------------------------------------
app.listen(3000, () => console.log('Serwer backend działa na porcie 3000'));